using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using Debug = UnityEngine.Debug;

public class EngineProcessManager : MonoBehaviour
{
    public static EngineProcessManager Instance;

    public string engineExecutablePath = "";
    public float requestTimeoutSeconds = 6f;
    public bool autoStart = false;

    private Process _process;
    private StreamWriter _stdin;
    private StreamReader _stdout;
    private int _requestCounter = 0;
    private readonly SemaphoreSlim _requestLock = new SemaphoreSlim(1,1);

    public bool IsRunning => _process != null && !_process.HasExited;
    public string ResolvedEnginePath { get; private set; }

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    void Start()
    {
        if (autoStart) StartEngine();
    }

    public void StartEngine()
    {
        if (IsRunning) return;

        ResolvedEnginePath = ResolveEnginePath();
        if (!File.Exists(ResolvedEnginePath))
        {
            Debug.LogError("Engine executable not found: " + ResolvedEnginePath);
            return;
        }

        var psi = new ProcessStartInfo
        {
            FileName = ResolvedEnginePath,
            WorkingDirectory = Path.GetDirectoryName(ResolvedEnginePath),
            UseShellExecute = false,
            RedirectStandardInput = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };

        _process = new Process { StartInfo = psi };
        _process.Start();

        _stdin = _process.StandardInput;
        _stdout = _process.StandardOutput;
    }

    public async Task<string> SendCommandAsync(string cmd, string payloadJson="{}")
    {
        if (!IsRunning)
            throw new Exception("Engine not running");

        await _requestLock.WaitAsync();

        try
        {
            string id = "req-" + (++_requestCounter);
            string json = "{\"id\":\"" + id + "\",\"cmd\":\"" + cmd + "\",\"payload\":" + payloadJson + "}";

            await _stdin.WriteLineAsync(json);
            await _stdin.FlushAsync();

            var readTask = _stdout.ReadLineAsync();
            var timeoutTask = Task.Delay(TimeSpan.FromSeconds(requestTimeoutSeconds));

            var completed = await Task.WhenAny(readTask, timeoutTask);

            if (completed == timeoutTask)
                throw new TimeoutException("Engine request timed out");

            return await readTask;
        }
        finally
        {
            _requestLock.Release();
        }
    }

    string ResolveEnginePath()
    {
        if (!string.IsNullOrEmpty(engineExecutablePath) && File.Exists(engineExecutablePath))
            return engineExecutablePath;

        string exe = "8d_chess_server_prototype.exe";
        string baseDir = AppDomain.CurrentDomain.BaseDirectory;

        string[] candidates = {
            Path.Combine(baseDir, exe),
            Path.Combine(baseDir, "Engine", exe)
        };

        foreach (var c in candidates)
            if (File.Exists(c)) return c;

        return exe;
    }
}

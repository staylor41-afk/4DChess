using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class PackagePreflightValidator : MonoBehaviour
{
    [TextArea(6,20)]
    public string lastReport;

    public void RunValidation()
    {
        List<string> issues = new List<string>();

        if (FindObjectOfType<EngineProcessManager>() == null)
            issues.Add("Missing EngineProcessManager");

        if (FindObjectOfType<EventSystem>() == null)
            issues.Add("Missing EventSystem");

        if (FindObjectOfType<SliceBoardRenderer>() == null)
            issues.Add("Missing SliceBoardRenderer");

        lastReport = issues.Count == 0
            ? "Preflight OK"
            : "Issues:\n- " + string.Join("\n- ", issues);

        Debug.Log(lastReport);
    }
}

using UnityEngine;

public class RuntimeRecoveryController : MonoBehaviour
{
    public EngineProcessManager engine;
    public PackagePreflightValidator validator;
    public BootstrapDiagnosticsPanel diagnostics;

    void Awake()
    {
        if (engine == null) engine = FindObjectOfType<EngineProcessManager>();
        if (validator == null) validator = FindObjectOfType<PackagePreflightValidator>();
        if (diagnostics == null) diagnostics = FindObjectOfType<BootstrapDiagnosticsPanel>();
    }

    public void RetryEngine()
    {
        if (engine == null) return;
        engine.StartEngine();
        diagnostics.Refresh();
    }

    public void RerunPreflight()
    {
        if (validator != null) validator.RunValidation();
        diagnostics.Refresh();
    }
}

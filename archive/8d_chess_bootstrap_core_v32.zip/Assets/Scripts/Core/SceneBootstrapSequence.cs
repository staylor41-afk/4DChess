using UnityEngine;

public class SceneBootstrapSequence : MonoBehaviour
{
    public EngineProcessManager engine;
    public PackagePreflightValidator preflight;
    public BootstrapDiagnosticsPanel diagnostics;

    void Start()
    {
        if (preflight == null) preflight = FindObjectOfType<PackagePreflightValidator>();
        if (engine == null) engine = FindObjectOfType<EngineProcessManager>();
        if (diagnostics == null) diagnostics = FindObjectOfType<BootstrapDiagnosticsPanel>();

        if (preflight != null)
            preflight.RunValidation();

        if (engine != null)
            engine.StartEngine();

        if (diagnostics != null)
            diagnostics.Refresh();
    }
}

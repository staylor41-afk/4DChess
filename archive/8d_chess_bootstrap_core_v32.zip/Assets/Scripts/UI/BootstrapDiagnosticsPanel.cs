using UnityEngine;
using UnityEngine.UI;

public class BootstrapDiagnosticsPanel : MonoBehaviour
{
    public Text diagnosticsText;

    public void Refresh()
    {
        if (diagnosticsText == null) return;

        var engine = FindObjectOfType<EngineProcessManager>();

        diagnosticsText.text =
            "Engine running: " + (engine != null && engine.IsRunning);
    }
}

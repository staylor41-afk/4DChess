using UnityEngine;
using UnityEngine.UI;

public class BuildStampPanel : MonoBehaviour
{
    public Text text;

    void Start()
    {
        if (text == null) return;

        text.text =
            "8D Chess Bootstrap v32\n" +
            (Debug.isDebugBuild ? "Development Build" : "Release Build") +
            "\nPlatform: " + Application.platform;
    }
}

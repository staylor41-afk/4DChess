using UnityEngine;
using UnityEngine.UI;

public class RuntimeRecoveryPanel : MonoBehaviour
{
    public RuntimeRecoveryController controller;
    public Button retryEngineButton;
    public Button rerunPreflightButton;

    void Start()
    {
        if (controller == null)
            controller = FindObjectOfType<RuntimeRecoveryController>();

        retryEngineButton.onClick.AddListener(() => controller.RetryEngine());
        rerunPreflightButton.onClick.AddListener(() => controller.RerunPreflight());
    }
}

using UnityEngine;
using UnityEngine.UI;

public class SimpleSceneHealthOverlay : MonoBehaviour
{
    public Text overlay;

    void Update()
    {
        if (overlay == null) return;

        bool engine = FindObjectOfType<EngineProcessManager>()?.IsRunning ?? false;
        bool eventSystem = FindObjectOfType<UnityEngine.EventSystems.EventSystem>() != null;
        bool board = FindObjectOfType<SliceBoardRenderer>() != null;

        overlay.text =
            "Engine: " + (engine ? "ON" : "OFF") +
            " | EventSystem: " + (eventSystem ? "OK" : "MISSING") +
            " | Board: " + (board ? "OK" : "MISSING");
    }
}

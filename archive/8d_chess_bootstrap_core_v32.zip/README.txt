8D Chess Bootstrap Core v32

This bundle merges v30 + v31 improvements into one clean package.

Included systems:
- EngineProcessManager (engine bridge)
- SceneBootstrapSequence (startup control)
- PackagePreflightValidator (scene validation)
- RuntimeRecoveryController (retry engine + preflight)
- BootstrapDiagnosticsPanel (engine status UI)
- RuntimeRecoveryPanel (buttons for recovery)
- BuildStampPanel (build info display)
- SimpleSceneHealthOverlay (live scene health)

Install:
Drop the Assets folder into your Unity project.

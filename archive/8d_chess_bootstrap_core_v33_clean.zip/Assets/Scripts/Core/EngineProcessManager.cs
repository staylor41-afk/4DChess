using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using Debug = UnityEngine.Debug;

public class EngineProcessManager : MonoBehaviour
{
    public static EngineProcessManager Instance;

    public string engineExecutablePath = "";
    public float requestTimeoutSeconds = 6f;
    public bool autoStart = false;

    private Process _process;
    private StreamWriter _stdin;
    private StreamReader _stdout;
    private int _requestCounter = 0;
    private readonly SemaphoreSlim _requestLock = new SemaphoreSlim(1, 1);

    public bool IsRunning => _process != null && !_process.HasExited;
    public string ResolvedEnginePath { get; private set; } = "";

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    void Start()
    {
        if (autoStart) StartEngine();
    }

    public void StartEngine()
    {
        if (IsRunning) return;

        ResolvedEnginePath = ResolveEnginePath();

        if (string.IsNullOrWhiteSpace(ResolvedEnginePath) || !File.Exists(ResolvedEnginePath))
        {
            Debug.LogError("Engine executable not found: " + ResolvedEnginePath);
            return;
        }

        var psi = new ProcessStartInfo
        {
            FileName = ResolvedEnginePath,
            WorkingDirectory = Path.GetDirectoryName(ResolvedEnginePath),
            UseShellExecute = false,
            RedirectStandardInput = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };

        _process = new Process { StartInfo = psi, EnableRaisingEvents = true };
        _process.ErrorDataReceived += (_, e) =>
        {
            if (!string.IsNullOrWhiteSpace(e.Data))
                Debug.LogWarning("[ENGINE STDERR] " + e.Data);
        };

        try
        {
            _process.Start();
            _stdin = _process.StandardInput;
            _stdout = _process.StandardOutput;
            _process.BeginErrorReadLine();
            Debug.Log("Engine started: " + ResolvedEnginePath);
        }
        catch (Exception ex)
        {
            Debug.LogError("Failed to start engine: " + ex);
        }
    }

    public async Task<string> SendCommandAsync(string cmd, string payloadJson = "{}")
    {
        if (!IsRunning)
            throw new Exception("Engine not running");

        await _requestLock.WaitAsync();

        try
        {
            string id = "req-" + (++_requestCounter);
            string json = "{\"id\":\"" + id + "\",\"cmd\":\"" + cmd + "\",\"payload\":" + payloadJson + "}";

            await _stdin.WriteLineAsync(json);
            await _stdin.FlushAsync();

            var readTask = _stdout.ReadLineAsync();
            var timeoutTask = Task.Delay(TimeSpan.FromSeconds(requestTimeoutSeconds));

            var completed = await Task.WhenAny(readTask, timeoutTask);
            if (completed == timeoutTask)
                throw new TimeoutException("Engine request timed out: " + cmd);

            string response = await readTask;
            if (string.IsNullOrWhiteSpace(response))
                throw new Exception("Empty engine response");

            return response;
        }
        finally
        {
            _requestLock.Release();
        }
    }

    string ResolveEnginePath()
    {
        if (!string.IsNullOrWhiteSpace(engineExecutablePath) && File.Exists(engineExecutablePath))
            return engineExecutablePath;

        string exeName =
            Application.platform == RuntimePlatform.WindowsEditor ||
            Application.platform == RuntimePlatform.WindowsPlayer
            ? "8d_chess_server_prototype.exe"
            : "8d_chess_server_prototype";

        string baseDir = AppDomain.CurrentDomain.BaseDirectory;
        string[] candidates = new[]
        {
            Path.Combine(baseDir, exeName),
            Path.Combine(baseDir, "Engine", exeName),
            Path.Combine(Application.dataPath, "..", exeName),
            Path.Combine(Application.dataPath, "..", "Engine", exeName),
        };

        foreach (var c in candidates)
        {
            string full = Path.GetFullPath(c);
            if (File.Exists(full)) return full;
        }

        return engineExecutablePath;
    }

    public void StopEngine()
    {
        try
        {
            if (_process != null && !_process.HasExited)
                _process.Kill();
        }
        catch (Exception ex)
        {
            Debug.LogWarning("StopEngine failed: " + ex.Message);
        }
    }

    void OnApplicationQuit()
    {
        StopEngine();
    }
}

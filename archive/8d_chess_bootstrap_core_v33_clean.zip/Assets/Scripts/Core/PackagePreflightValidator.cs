using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class PackagePreflightValidator : MonoBehaviour
{
    [TextArea(6, 20)]
    public string lastReport = "";

    public void RunValidation()
    {
        List<string> issues = new List<string>();

        if (FindFirstObjectByType<EngineProcessManager>() == null)
            issues.Add("Missing EngineProcessManager");

        if (FindFirstObjectByType<EventSystem>() == null)
            issues.Add("Missing EventSystem");

        if (FindFirstObjectByType<Canvas>() == null)
            issues.Add("Missing Canvas");

        lastReport = issues.Count == 0
            ? "Preflight OK"
            : "Preflight issues:\n- " + string.Join("\n- ", issues);

        Debug.Log(lastReport);
    }
}

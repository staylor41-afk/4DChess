using UnityEngine;

public class RuntimeRecoveryController : MonoBehaviour
{
    public EngineProcessManager engine;
    public PackagePreflightValidator validator;
    public BootstrapDiagnosticsPanel diagnostics;

    void Awake()
    {
        if (engine == null) engine = FindFirstObjectByType<EngineProcessManager>();
        if (validator == null) validator = FindFirstObjectByType<PackagePreflightValidator>();
        if (diagnostics == null) diagnostics = FindFirstObjectByType<BootstrapDiagnosticsPanel>();
    }

    public void RetryEngine()
    {
        if (engine == null) return;
        engine.StopEngine();
        engine.StartEngine();
        RefreshDiagnostics();
    }

    public void RerunPreflight()
    {
        if (validator != null) validator.RunValidation();
        RefreshDiagnostics();
    }

    public void RefreshDiagnostics()
    {
        if (diagnostics != null) diagnostics.Refresh();
    }
}

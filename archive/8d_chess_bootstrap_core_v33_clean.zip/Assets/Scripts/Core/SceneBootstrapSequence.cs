using UnityEngine;

public class SceneBootstrapSequence : MonoBehaviour
{
    public EngineProcessManager engine;
    public PackagePreflightValidator preflight;
    public BootstrapDiagnosticsPanel diagnostics;

    void Start()
    {
        if (preflight == null) preflight = FindFirstObjectByType<PackagePreflightValidator>();
        if (engine == null) engine = FindFirstObjectByType<EngineProcessManager>();
        if (diagnostics == null) diagnostics = FindFirstObjectByType<BootstrapDiagnosticsPanel>();

        if (preflight != null)
            preflight.RunValidation();

        if (engine != null)
            engine.StartEngine();

        if (diagnostics != null)
            diagnostics.Refresh();
    }
}

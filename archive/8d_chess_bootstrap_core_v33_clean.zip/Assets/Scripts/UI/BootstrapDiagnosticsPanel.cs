using UnityEngine;
using TMPro;

public class BootstrapDiagnosticsPanel : MonoBehaviour
{
    public TMP_Text diagnosticsText;

    public void Refresh()
    {
        if (diagnosticsText == null) return;

        var engine = FindFirstObjectByType<EngineProcessManager>();
        diagnosticsText.text =
            "Engine running: " + (engine != null && engine.IsRunning) +
            "\nPath: " + (engine != null ? engine.ResolvedEnginePath : "(none)");
    }
}

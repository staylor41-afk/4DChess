using UnityEngine;
using TMPro;

public class BuildStampPanel : MonoBehaviour
{
    public TMP_Text text;
    public string bundleVersion = "v33";
    public string buildLabel = "8D Chess Bootstrap";

    void Start()
    {
        if (text == null) return;

        text.text =
            buildLabel + "\n" +
            bundleVersion + "\n" +
            (Debug.isDebugBuild ? "Development Build" : "Release Build") + "\n" +
            Application.platform;
    }
}

using UnityEngine;
using UnityEngine.UI;

public class RuntimeRecoveryPanel : MonoBehaviour
{
    public RuntimeRecoveryController controller;
    public Button retryEngineButton;
    public Button rerunPreflightButton;

    void Start()
    {
        if (controller == null)
            controller = FindFirstObjectByType<RuntimeRecoveryController>();

        if (retryEngineButton != null)
            retryEngineButton.onClick.AddListener(() => controller?.RetryEngine());

        if (rerunPreflightButton != null)
            rerunPreflightButton.onClick.AddListener(() => controller?.RerunPreflight());
    }
}

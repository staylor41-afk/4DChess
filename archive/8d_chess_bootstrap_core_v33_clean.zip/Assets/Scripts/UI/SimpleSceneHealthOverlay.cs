using UnityEngine;
using TMPro;
using UnityEngine.EventSystems;

public class SimpleSceneHealthOverlay : MonoBehaviour
{
    public TMP_Text overlay;

    void Update()
    {
        if (overlay == null) return;

        bool engine = FindFirstObjectByType<EngineProcessManager>()?.IsRunning ?? false;
        bool eventSystem = FindFirstObjectByType<EventSystem>() != null;
        bool canvas = FindFirstObjectByType<Canvas>() != null;

        overlay.text =
            "Engine: " + (engine ? "ON" : "OFF") +
            " | EventSystem: " + (eventSystem ? "OK" : "MISSING") +
            " | UI: " + (canvas ? "OK" : "MISSING");
    }
}

8D Chess Bootstrap Core v33 (clean)

This is a board-agnostic bootstrap bundle for a fresh Unity project.

Included:
- EngineProcessManager
- PackagePreflightValidator
- SceneBootstrapSequence
- RuntimeRecoveryController
- BootstrapDiagnosticsPanel
- RuntimeRecoveryPanel
- BuildStampPanel
- SimpleSceneHealthOverlay

Important:
- This version does NOT reference SliceBoardRenderer or other chess-board scripts.
- It is meant to compile cleanly in a brand-new Unity project.
- UI scripts use TextMeshPro (TMP_Text).

Install:
Copy the Assets folder into your Unity project.

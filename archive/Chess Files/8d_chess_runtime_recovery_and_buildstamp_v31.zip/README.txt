8D Chess runtime recovery + build stamp v31

What this adds
--------------
- RuntimeRecoveryController
- RuntimeRecoveryPanel
- BuildStampPanel
- SimpleSceneHealthOverlay
- quick-start notes for PackageBootstrap

Why this is useful now
----------------------
At this stage, the most likely problems are operational:
- engine path wrong
- engine fails to launch on first try
- preflight needs rerunning after a quick fix
- packaged build confusion about which build/version is running

These additions make first packaged tests easier to recover and easier to read.

Files
-----
- unity-client/Assets/Scripts/Core/RuntimeRecoveryController.cs
- unity-client/Assets/Scripts/UI/RuntimeRecoveryPanel.cs
- unity-client/Assets/Scripts/UI/BuildStampPanel.cs
- unity-client/Assets/Scripts/UI/SimpleSceneHealthOverlay.cs
- unity-client/Assets/Scripts/UI/PackageBootstrapQuickStart.txt

using UnityEngine;

// Small recovery helper for packaged builds.
// Lets the user retry key startup steps without restarting the whole app.
public class RuntimeRecoveryController : MonoBehaviour
{
    public EngineProcessManager engineProcessManager;
    public PackagePreflightValidator preflightValidator;
    public BootstrapDiagnosticsPanel diagnosticsPanel;

    void Awake()
    {
        if (engineProcessManager == null) engineProcessManager = FindObjectOfType<EngineProcessManager>();
        if (preflightValidator == null) preflightValidator = FindObjectOfType<PackagePreflightValidator>();
        if (diagnosticsPanel == null) diagnosticsPanel = FindObjectOfType<BootstrapDiagnosticsPanel>();
    }

    public void RetryEngineStartup()
    {
        if (engineProcessManager == null) return;
        engineProcessManager.StopEngine();
        engineProcessManager.StartEngine();
        RefreshDiagnostics();
    }

    public void RerunPreflight()
    {
        if (preflightValidator != null) preflightValidator.RunValidation();
        RefreshDiagnostics();
    }

    public void RefreshDiagnostics()
    {
        if (diagnosticsPanel != null) diagnosticsPanel.Refresh();
    }
}

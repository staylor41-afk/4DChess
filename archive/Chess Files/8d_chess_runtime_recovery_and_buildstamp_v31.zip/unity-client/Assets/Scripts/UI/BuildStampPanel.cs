using UnityEngine;
using UnityEngine.UI;

// Displays obvious build context so packaged tests are easier to track.
public class BuildStampPanel : MonoBehaviour
{
    public Text buildStampText;
    public string buildLabel = "PackageBootstrap Dev Build";
    public string bundleVersion = "v31";

    void Start()
    {
        if (buildStampText == null) return;

        string mode = Debug.isDebugBuild ? "Development Build" : "Release Build";
        buildStampText.text =
            buildLabel +
            "\n" + bundleVersion +
            "\n" + mode +
            "\n" + Application.platform;
    }
}

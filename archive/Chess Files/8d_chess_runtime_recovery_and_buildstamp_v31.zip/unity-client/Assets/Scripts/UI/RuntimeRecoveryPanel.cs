using UnityEngine;
using UnityEngine.UI;

// Simple packaged-build panel with explicit recovery actions.
public class RuntimeRecoveryPanel : MonoBehaviour
{
    public RuntimeRecoveryController recoveryController;
    public Button retryEngineButton;
    public Button rerunPreflightButton;
    public Button refreshDiagnosticsButton;

    void Start()
    {
        if (recoveryController == null) recoveryController = FindObjectOfType<RuntimeRecoveryController>();

        if (retryEngineButton != null)
            retryEngineButton.onClick.AddListener(() =>
            {
                if (recoveryController != null) recoveryController.RetryEngineStartup();
            });

        if (rerunPreflightButton != null)
            rerunPreflightButton.onClick.AddListener(() =>
            {
                if (recoveryController != null) recoveryController.RerunPreflight();
            });

        if (refreshDiagnosticsButton != null)
            refreshDiagnosticsButton.onClick.AddListener(() =>
            {
                if (recoveryController != null) recoveryController.RefreshDiagnostics();
            });
    }
}

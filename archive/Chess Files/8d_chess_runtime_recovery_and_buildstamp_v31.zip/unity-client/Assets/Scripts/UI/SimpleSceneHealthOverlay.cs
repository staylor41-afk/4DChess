using UnityEngine;
using UnityEngine.UI;

// Tiny always-on overlay so obvious failures are visible at a glance.
public class SimpleSceneHealthOverlay : MonoBehaviour
{
    public Text overlayText;

    void Update()
    {
        if (overlayText == null) return;

        var epm = FindObjectOfType<EngineProcessManager>();
        var eventSystemPresent = FindObjectOfType<UnityEngine.EventSystems.EventSystem>() != null;
        var renderer = FindObjectOfType<SliceBoardRenderer>();

        overlayText.text =
            "Engine: " + ((epm != null && epm.IsRunning) ? "ON" : "OFF") +
            " | EventSystem: " + (eventSystemPresent ? "OK" : "MISSING") +
            " | Board: " + (renderer != null ? "OK" : "MISSING");
    }
}
